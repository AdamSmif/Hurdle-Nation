# Godot-EasyBlend
![image](https://user-images.githubusercontent.com/1023003/40279962-da913c82-5c11-11e8-8a89-3802dd6e5ede.png)

EasyBlend is a shader which allows you to set a custom blending mode for your canvas item.\
Included are many of the blending modes you will find in common image editors.\
<sub>(Screenshot sample source: &nbsp; @tarenagashikuzu on Twitter)</sub>
